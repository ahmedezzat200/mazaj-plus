# common app init
