from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from .responses import success_response

class HealthCheckView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return success_response({
            "status": "ok",
            "service": "mazaj-backend"
        })
