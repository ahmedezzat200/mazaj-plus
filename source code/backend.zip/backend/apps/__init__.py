# Apps module init
